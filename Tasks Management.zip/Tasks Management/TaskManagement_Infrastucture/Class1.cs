﻿namespace TaskManagement_Infrastucture
{
    public class Class1
    {

    }
}
